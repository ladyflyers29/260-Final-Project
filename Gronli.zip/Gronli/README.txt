    I wasn't sure how to do the UML Doc so I gave it my best shot. Some of my scripts took only one function from another script and I wasn't sure how to do that in the UML doc. I also didn't know what the difference between the arrows and things were so I just used and arrow. But I tried.

    If you are looking through the code the lines that are using other scripts look like this ->  

FindObjectsOfType<GameSession>().Length;

Where GameSession is a script name and Length is the function being called.
